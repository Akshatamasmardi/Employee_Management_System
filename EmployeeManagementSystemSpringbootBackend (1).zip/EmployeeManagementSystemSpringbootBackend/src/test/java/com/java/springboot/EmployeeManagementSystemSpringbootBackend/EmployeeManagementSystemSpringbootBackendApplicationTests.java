package com.java.springboot.EmployeeManagementSystemSpringbootBackend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EmployeeManagementSystemSpringbootBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
